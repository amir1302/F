require('./setting')
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, downloadContentFromMessage, makeInMemoryStore, jidDecode, getAggregateVotesInPollMessage, proto } = require("@whiskeysockets/baileys")
const fs = require('fs')
const pino = require('pino')
const chalk = require('chalk')
const path = require('path')
const readline = require("readline");
const axios = require('axios')
const FileType = require('file-type')
const yargs = require('yargs/yargs')
const _ = require('lodash')
const { Boom } = require('@hapi/boom')
const PhoneNumber = require('awesome-phonenumber')
const usePairingCode = true
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep } = require('./lib/myfunc')
const { isSetClose,
    addSetClose,
    removeSetClose,
    changeSetClose,
    getTextSetClose,
    isSetDone,
    addSetDone,
    removeSetDone,
    changeSetDone,
    getTextSetDone,
    isSetLeft,
    addSetLeft,
    removeSetLeft,
    changeSetLeft,
    getTextSetLeft,
    isSetOpen,
    addSetOpen,
    removeSetOpen,
    changeSetOpen,
    getTextSetOpen,
    isSetProses,
    addSetProses,
    removeSetProses,
    changeSetProses,
    getTextSetProses,
    isSetWelcome,
    addSetWelcome,
    removeSetWelcome,
    changeSetWelcome,
    getTextSetWelcome,
    addSewaGroup,
    getSewaExpired,
    getSewaPosition,
    expiredCheck,
    checkSewaGroup
} = require("./lib/store")
const pushname = smsg.pushName
let set_welcome_db = JSON.parse(fs.readFileSync('./database/set_welcome.json'));
let set_left_db = JSON.parse(fs.readFileSync('./database/set_left.json'));
let _welcome = JSON.parse(fs.readFileSync('./database/welcome.json'));
let _left = JSON.parse(fs.readFileSync('./database/left.json'));
let set_proses = JSON.parse(fs.readFileSync('./database/set_proses.json'));
let set_done = JSON.parse(fs.readFileSync('./database/set_done.json'));
let set_open = JSON.parse(fs.readFileSync('./database/set_open.json'));
let set_close = JSON.parse(fs.readFileSync('./database/set_close.json'));
let sewa = JSON.parse(fs.readFileSync('./database/sewa.json'));
let setpay = JSON.parse(fs.readFileSync('./database/pay.json'));
let opengc = JSON.parse(fs.readFileSync('./database/opengc.json'));
let antilink = JSON.parse(fs.readFileSync('./database/antilink.json'));
let antiwame = JSON.parse(fs.readFileSync('./database/antiwame.json'));
let antilink2 = JSON.parse(fs.readFileSync('./database/antilink2.json'));
let antiwame2 = JSON.parse(fs.readFileSync('./database/antiwame2.json'));
let db_respon_list = JSON.parse(fs.readFileSync('./database/list.json'));
const question = (text) => {
  const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
  });
  return new Promise((resolve) => {
rl.question(text, resolve)
  })
};
//=================================================//
var low
try {
low = require('lowdb')
} catch (e) {
low = require('./lib/lowdb')}
//=================================================//
const { Low, JSONFile } = low
const mongoDB = require('./lib/mongoDB')
//=================================================//
//=================================================//
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
//=================================================//
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
/https?:\/\//.test(opts['db'] || '') ?
new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
new mongoDB(opts['db']) :
new JSONFile(`./src/database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
if (global.db.data !== null) return
global.db.READ = true
await global.db.read()
global.db.READ = false
global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})}
  global.db.chain = _.chain(global.db.data)}
loadDatabase()
//=================================================//
//=================================================//
 
async function connectToWhatsApp() {
const { state, saveCreds } = await useMultiFileAuthState(global.sessionName)
console.log(chalk.red.bold('⡏⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠋⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠙⠉⠉⠉⠹\n⡇⢸⣿⡟⠛⢿⣷ ⢸⣿⡟⠛⢿⣷⡄⢸⣿⡇ ⢸⣿⡇⢸⣿⡇ ⢸⣿⡇ \n⡇⢸⣿⣧⣤⣾⠿ ⢸⣿⣇⣀⣸⡿⠃⢸⣿⡇ ⢸⣿⡇⢸⣿⣇⣀⣸⣿⡇ \n⡇⢸⣿⡏⠉⢹⣿⡆⢸⣿⡟⠛⢻⣷⡄⢸⣿⡇ ⢸⣿⡇⢸⣿⡏⠉⢹⣿⡇ \n⡇⢸⣿⣧⣤⣼⡿⠃⢸⣿⡇ ⢸⣿⡇⠸⣿⣧⣤⣼⡿⠁⢸⣿⡇ ⢸⣿⡇ \n⣇⣀⣀⣀⣀⣀⣀⣄⣀⣀⣀⣀⣀⣀⣀⣠⣀⡈⠉⣁⣀⣄⣀⣀⣀⣠⣀⣀⣀⣰\n⣇⣿⠘⣿⣿⣿⡿⡿⣟⣟⢟⢟⢝⠵⡝⣿⡿⢂⣼⣿⣷⣌⠩⡫⡻⣝⠹⢿⣿⣷\n⡆⣿⣆⠱⣝⡵⣝⢅⠙⣿⢕⢕⢕⢕⢝⣥⢒⠅⣿⣿⣿⡿⣳⣌⠪⡪⣡⢑⢝⣇\n⡆⣿⣿⣦⠹⣳⣳⣕⢅⠈⢗⢕⢕⢕⢕⢕⢈⢆⠟⠋⠉⠁⠉⠉⠁⠈⠼⢐⢕⢽\n⡗⢰⣶⣶⣦⣝⢝⢕⢕⠅⡆⢕⢕⢕⢕⢕⣴⠏⣠⡶⠛⡉⡉⡛⢶⣦⡀⠐⣕⢕\n⡝⡄⢻⢟⣿⣿⣷⣕⣕⣅⣿⣔⣕⣵⣵⣿⣿⢠⣿⢠⣮⡈⣌⠨⠅⠹⣷⡀⢱⢕\n⡝⡵⠟⠈⢀⣀⣀⡀⠉⢿⣿⣿⣿⣿⣿⣿⣿⣼⣿⢈⡋⠴⢿⡟⣡⡇⣿⡇⡀⢕\n⡝⠁⣠⣾⠟⡉⡉⡉⠻⣦⣻⣿⣿⣿⣿⣿⣿⣿⣿⣧⠸⣿⣦⣥⣿⡇⡿⣰⢗⢄\n⠁⢰⣿⡏⣴⣌⠈⣌⠡⠈⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣬⣉⣉⣁⣄⢖⢕⢕⢕\n⡀⢻⣿⡇⢙⠁⠴⢿⡟⣡⡆⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣵⣵⣿\n⡻⣄⣻⣿⣌⠘⢿⣷⣥⣿⠇⣿⣿⣿⣿⣿⣿⠛⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣷⢄⠻⣿⣟⠿⠦⠍⠉⣡⣾⣿⣿⣿⣿⣿⣿⢸⣿⣦⠙⣿⣿⣿⣿⣿⣿⣿⣿⠟\n⡝⡵⡈⢟⢕⢕⢕⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣶⣿⣿⣿⣿⣿⠿⠋⣀⣈⠙\n⡝⡵⡕⡀⠑⠳⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠛⢉⡠⡲⡫⡪⡪⡣\n\n𝐈 𝐍 𝐅 𝐎 𝐑 𝐌 𝐀 𝐓 𝐈 𝐎 𝐍\n𝐃𝐞𝐯𝐥𝐨𝐩𝐞𝐫 𝟏 : 𝐃𝐫𝐚𝐲𝐲 \n𝐃𝐞𝐯𝐥𝐨𝐩𝐞𝐫 𝟐 : 𝐀𝐧𝐝𝐫𝐚𝐙𝐲\n𝐒𝐜𝐫𝐢𝐩𝐭 : 𝐙𝐞𝐧𝐨 𝐗 𝐀𝐠𝐥𝐞𝐫 𝐅𝐨𝐫𝐠𝐞𝐫\n\n𝐌𝐚𝐬𝐮𝐤𝐢 𝐧𝐨𝐦𝐨𝐫 𝐋𝐮 𝐧𝐲𝐞𝐭 𝐣𝐚𝐧𝐠𝐚𝐧 𝐩𝐚𝐤𝐞 𝟎𝟖 𝐚𝐭𝐚𝐮 +𝟔𝟐 𝐰𝐚𝐣𝐢𝐛 : (𝟼𝟸𝚡𝚡𝚡𝚡):'))
const drayyy = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: ['Chrome (Linux)', '', '']
});
if(usePairingCode && !drayyy.authState.creds.registered) {
		const phoneNumber = await question('𝚈𝚘𝚞𝚛 𝙽𝚞𝚖𝚋𝚎𝚛 ☞');
		const code = await drayyy.requestPairingCode(phoneNumber.trim())
		console.log(`Pairing code: ${code}`)

	}
drayyy.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
console.log(lastDisconnect.error, 'deeppink')
if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
process.exit()
} else if (reason === DisconnectReason.badSession) {
console.log(`Bad Session File, Please Delete Session and Scan Again`)
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink')
process.exit()
} else if (reason === DisconnectReason.connectionLost) {
console.log('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink')
process.exit()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log('Connection Replaced, Another New Session Opened, Please Close Current Session First')
drayyy.logout()
} else if (reason === DisconnectReason.loggedOut) {
console.log(`Device Logged Out, Please Scan Again And Run.`)
drayyy.logout()
} else if (reason === DisconnectReason.restartRequired) {
console.log('Restart Required, Restarting...')
await connectToWhatsApp()
} else if (reason === DisconnectReason.timedOut) {
console.log('Connection TimedOut, Reconnecting...')
connectToWhatsApp()
}
} else if (connection === "connecting") {

} else if (connection === "open") {

drayyy.sendMessage(`6285767108452@s.whatsapp.net`, { text: `\`𝐇𝐢 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐁𝐨𝐭𝐳 𝐯𝟔 𝐁𝐞𝐫𝐡𝐚𝐬𝐢𝐥 𝐓𝐞𝐫-𝐂𝐨𝐧𝐧𝐞𝐜𝐭

\`𝐒𝐈𝐀𝐏𝐀 𝐍𝐀𝐌𝐀 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑 𝐘𝐀𝐍𝐆 𝐏𝐄𝐑𝐓𝐀𝐌𝐀 𝐌𝐄𝐍𝐂𝐈𝐏𝐓𝐀𝐊𝐀𝐍 𝐁𝐔𝐆?
𝐉𝐀𝐖𝐀𝐁𝐀𝐍 𝐃𝐀𝐍 𝐂𝐑𝐈𝐓𝐀 𝐒𝐈𝐍𝐆𝐊𝐀𝐓 𝐍𝐘𝐀 :
𝐛𝐚𝐜𝐚 𝐝𝐚𝐧 𝐬𝐢𝐦𝐚𝐤 𝐬𝐞𝐥𝐞𝐧𝐠𝐤𝐚𝐩𝐧𝐲𝐚

𝐁𝐮𝐠 𝐛𝐞𝐫𝐚𝐬𝐚𝐥 𝐝𝐚𝐫𝐢 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐀𝐆𝐋𝐄𝐑 𝐅𝐎𝐆𝐄𝐑
𝐍𝐀𝐌𝐀 𝐓𝐎𝐊𝐎𝐇 𝐏𝐄𝐑𝐀𝐍 𝐊𝐄𝐋𝐔𝐀𝐑𝐆𝐀 :
𝐀𝐲𝐚𝐡 : 𝐋𝐞𝐨𝐧 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫 
𝐈𝐛𝐮 : 𝐘𝐨𝐮𝐫𝐬𝐡𝐚 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫
𝐌𝐞𝐦𝐢𝐥𝐢𝐤𝐢 𝟓 𝐚𝐧𝐚𝐤 
𝐚𝐧𝐚𝐤 𝐩𝐞𝐫𝐭𝐚𝐦𝐚 : 𝐘𝐚𝐧𝐳𝐲 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫 (𝐥𝐚𝐤𝐢-𝐥𝐚𝐤𝐢)
𝐚𝐧𝐚𝐤 𝐤𝐞 𝐝𝐮𝐚 : 𝐋𝐞𝐯𝐢 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫 (𝐥𝐚𝐤𝐢-𝐥𝐚𝐤𝐢)
𝐚𝐧𝐚𝐤 𝐤𝐞 𝐭𝐢𝐠𝐚 : 𝐂𝐢𝐜𝐢 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫 (𝐩𝐞𝐫𝐞𝐦𝐩𝐮𝐚𝐧)
𝐚𝐧𝐚𝐤 𝐤𝐞 𝐞𝐦𝐩𝐚𝐭 : 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫 (𝐥𝐚𝐤𝐢-𝐥𝐚𝐤𝐢)
𝐚𝐧𝐚𝐤 𝐤𝐞 𝐥𝐢𝐦𝐚 : 𝐗𝐢𝐧𝐳𝐲 𝐚𝐠𝐥𝐞𝐫 𝐟𝐨𝐠𝐞𝐫𝐬 (𝐩𝐞𝐫𝐞𝐦𝐩𝐮𝐚𝐧)

𝐊𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐢𝐧𝐢 𝐝𝐮𝐥𝐮 𝐝𝐢 𝐛𝐮𝐚𝐭 𝐮𝐧𝐭𝐮𝐤 𝐦𝐞𝐧𝐠𝐚𝐤𝐬𝐞𝐬 𝐝𝐚𝐭𝐚 𝐯𝐢𝐬𝐮𝐚𝐥, 𝐮𝐧𝐭𝐮𝐤 𝐦𝐞𝐧𝐢𝐧𝐠𝐤𝐚𝐭𝐤𝐚𝐧 𝐀𝐐 𝐲𝐚𝐧𝐠 𝐭𝐢𝐧𝐠𝐠𝐢 𝐝𝐚𝐥𝐚𝐦 𝐛𝐢𝐝𝐚𝐧𝐠 𝐞𝐤𝐨𝐬𝐢𝐬𝐭𝐞𝐦 𝐩𝐞𝐦𝐫𝐨𝐠𝐫𝐚𝐦𝐚𝐧, 𝐭𝐮𝐣𝐮𝐚𝐧 𝐝𝐚𝐫𝐢 𝐀𝐆𝐋𝐄𝐑 𝐅𝐎𝐑𝐆𝐄𝐑, 𝐦𝐞𝐧𝐠𝐚𝐤𝐬𝐞𝐬 𝐠𝐞𝐧𝐞𝐫𝐚𝐬𝐢 𝐢𝐧𝐭𝐞𝐫𝐧𝐚𝐬𝐢𝐨𝐧𝐚𝐥 𝐬𝐲𝐬𝐭𝐞𝐦 𝐤𝐞𝐦𝐚𝐣𝐮𝐚𝐧 𝐈𝐧𝐝𝐨𝐧𝐞𝐬𝐢𝐚, 𝐬𝐞𝐩𝐞𝐫𝐭𝐢 𝐚𝐝𝐚 𝐧𝐲𝐚 𝐚𝐧𝐝𝐫𝐨𝐢𝐝, 𝐢𝐨𝐬, 𝐮𝐢, 𝐔𝐌𝐌𝐈, 𝐯𝐢𝐫𝐮𝐬 𝐢𝐧𝐭𝐞𝐧𝐞𝐭 𝐝𝐚𝐧 𝐬𝐲𝐬𝐭𝐞𝐦 𝐥𝐚𝐢𝐧𝐧𝐲𝐚, 𝐝𝐚𝐧 𝐝𝐚𝐥𝐚𝐦 𝐬𝐮𝐚𝐭𝐮 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐀𝐆𝐋𝐄𝐑 𝐅𝐎𝐑𝐆𝐄𝐑 𝐛𝐞𝐫𝐜𝐞𝐫𝐚𝐢 𝐘𝐨𝐮𝐫 𝐝𝐚𝐧 𝐋𝐞𝐨𝐧 𝐦𝐞𝐦𝐢𝐡𝐚𝐤 𝐛𝐞𝐥𝐚𝐡 𝐚𝐧𝐚𝐤, 𝐝𝐚𝐧 𝐚𝐧𝐚𝐤 𝐩𝐚𝐥𝐢𝐧𝐠 𝐝𝐢 𝐬𝐢𝐚𝐤𝐚𝐧 𝐚𝐝𝐚𝐥𝐚𝐡 𝐀𝐧𝐝𝐫𝐚𝐙𝐲, 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐬𝐞𝐣𝐚𝐤 𝐦𝐚𝐬𝐢𝐡 𝐓𝐊 𝐝𝐢𝐚 𝐝𝐢 𝐭𝐢𝐭𝐢𝐩'𝐤𝐚𝐧/𝐝𝐢 𝐚𝐧𝐮𝐭 𝐤𝐞𝐩𝐚𝐝𝐚 𝐃𝐄𝐕𝐘 𝐄𝐕𝐀 𝐏𝐄𝐑𝐌𝐀𝐍𝐀 𝐲𝐚𝐧𝐠 𝐬𝐮𝐝𝐚𝐡 𝐦𝐞𝐦𝐢𝐥𝐢𝐤𝐢 𝐬𝐞𝐨𝐫𝐚𝐧𝐠 𝐬𝐮𝐚𝐦𝐢 𝐛𝐞𝐫𝐧𝐚𝐦𝐚 𝐇𝐀𝐑𝐘𝐎𝐍𝐎.

𝐧𝐚𝐦𝐚 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐤𝐢𝐧𝐢 𝐝𝐢 𝐮𝐛𝐚𝐡 𝐦𝐞𝐧𝐣𝐚𝐝𝐢 𝐖𝐢𝐥𝐥𝐲𝐚𝐧𝐝𝐫𝐚 𝐏𝐫𝐚𝐭𝐚𝐦𝐚, 𝐨𝐥𝐞𝐡 𝐬𝐞𝐨𝐫𝐚𝐧𝐠 𝐢𝐛𝐮 𝐝𝐚𝐧 𝐚𝐲𝐚𝐡 𝐬𝐚𝐦𝐛𝐮𝐧𝐠𝐧𝐲𝐚 𝐩𝐚𝐝𝐚 𝐔𝐦𝐮𝐫 𝟔 𝐓𝐚𝐡𝐮𝐧, 𝐬𝐢𝐧𝐠𝐤𝐚𝐭 𝐜𝐞𝐫𝐢𝐭𝐚 𝐤𝐞𝐭𝐢𝐤𝐚 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐭𝐢𝐧𝐠𝐠𝐚𝐥 𝐛𝐞𝐫𝐬𝐚𝐦𝐚 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐬𝐚𝐦𝐛𝐮𝐧𝐠 𝐧𝐲𝐚 𝐝𝐢𝐚 𝐡𝐢𝐝𝐮𝐩 𝐬𝐞𝐩𝐞𝐫𝐭𝐢 𝐥𝐚𝐲𝐚𝐤 𝐧𝐲𝐚 𝐨𝐫𝐚𝐧𝐠 𝐛𝐢𝐚𝐬𝐚 𝐝𝐚𝐧 𝐝𝐢 𝐚𝐧𝐠𝐠𝐚𝐩 𝐦𝐞𝐧𝐣𝐚𝐝𝐢 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚/𝐚𝐧𝐚𝐤 𝐤𝐚𝐧𝐝𝐮𝐧𝐠𝐧𝐲𝐚

𝐬𝐞𝐭𝐚𝐥𝐚𝐡 𝐤𝐞𝐡𝐢𝐝𝐮𝐩𝐚𝐧 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐛𝐚𝐫𝐮 𝐝𝐚𝐫𝐢 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐝𝐢𝐚 𝐦𝐞𝐦𝐢𝐥𝐢𝐤𝐢 𝟐 𝐚𝐝𝐢𝐤 𝐋𝐚𝐤𝐢-𝐥𝐚𝐤𝐢 𝐝𝐚𝐧 𝐩𝐞𝐫𝐞𝐦𝐩𝐮𝐚𝐧, 𝐬𝐞𝐭𝐞𝐥𝐚𝐡 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐒𝐌𝐏 𝐝𝐢𝐚 𝐬𝐮𝐝𝐚𝐡 𝐦𝐞𝐦𝐢𝐥𝐢𝐤𝐢 𝐡𝐚𝐧𝐝𝐩𝐡𝐨𝐧𝐞 𝐀𝐧𝐝𝐫𝐨𝐢𝐝, 𝐝𝐢 𝐦𝐞𝐧𝐠𝐠𝐮𝐧𝐚𝐤𝐚𝐧 𝐚𝐧𝐝𝐫𝐨𝐢𝐝 𝐝𝐞𝐧𝐠𝐚𝐧 𝐬𝐞𝐦𝐩𝐮𝐫𝐧𝐚 𝐩𝐚𝐝𝐚 𝐤𝐞𝐜𝐞𝐫𝐝𝐚𝐬 𝐬𝐲𝐭𝐞𝐦 𝐚𝐧𝐝𝐫𝐢, 𝐝𝐚𝐧 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐢𝐧𝐢 𝐦𝐞𝐦𝐢𝐥𝐢𝐤𝐢 𝐛𝐚𝐲𝐚𝐧𝐠𝐚𝐧 𝐣𝐢𝐰𝐚 𝐩𝐚𝐝𝐚 𝐝𝐢𝐫𝐢𝐧𝐲𝐚 𝐛𝐚𝐡𝐰𝐚 𝐝𝐢𝐚 𝐛𝐮𝐤𝐚𝐧 𝐥𝐚𝐡 𝐚𝐧𝐚𝐤 𝐤𝐚𝐧𝐝𝐮𝐧𝐠 𝐝𝐚𝐫𝐢 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐛𝐚𝐫𝐮𝐧𝐲𝐚.

𝐬𝐢𝐧𝐠𝐤𝐚𝐭 𝐜𝐞𝐫𝐢𝐭𝐚 𝐬𝐚𝐚𝐭 𝐬𝐞𝐤𝐨𝐥𝐚𝐡 𝐒𝐌𝐊 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐦𝐮𝐥𝐚𝐢 𝐬𝐚𝐝𝐚𝐫/𝐭𝐚𝐡𝐮 𝐝𝐢 𝐛𝐮𝐤𝐚𝐧 𝐚𝐧𝐚𝐤 𝐤𝐚𝐧𝐝𝐮𝐧𝐠 𝐝𝐚𝐫𝐢 𝐬𝐞𝐨𝐫𝐚𝐧𝐠 𝐢𝐛𝐮 𝐃𝐄𝐕𝐘, 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐤𝐢𝐧𝐢 𝐬𝐮𝐝𝐚𝐡 𝐦𝐮𝐥𝐚𝐢 𝐛𝐢𝐬𝐚 𝐦𝐞𝐧𝐞𝐦𝐮𝐤𝐚𝐧 𝐤𝐞𝐥𝐮𝐚𝐫𝐠𝐚 𝐧𝐲𝐚 𝐬𝐞𝐜𝐚𝐫𝐚 𝐯𝐢𝐬𝐮𝐚𝐥𝐢𝐬𝐚𝐬𝐢 𝐲𝐚𝐢𝐭𝐮 𝐚𝐝𝐚𝐥𝐚𝐡 𝐂𝐢𝐜𝐢 𝐀𝐆𝐋𝐄𝐑 𝐅𝐎𝐑𝐆𝐄𝐑 𝐤𝐚𝐤𝐚𝐤 𝐝𝐚𝐫𝐢 𝐀𝐧𝐝𝐫𝐚𝐙𝐲, 𝐰𝐚𝐥𝐚𝐮𝐩𝐮𝐧 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐛𝐞𝐥𝐮𝐦 𝐛𝐢𝐬𝐚 𝐦𝐞𝐧𝐞𝐦𝐮𝐢 𝐤𝐚𝐤𝐚𝐤 𝐧𝐲𝐚 𝐬𝐢 𝐂𝐢𝐜𝐢 𝐝𝐢𝐚 𝐬𝐞𝐧𝐚𝐧𝐠 𝐰𝐚𝐥𝐚𝐮𝐩𝐮𝐧 𝐛𝐢𝐬𝐚 𝐧𝐠𝐨𝐛𝐫𝐨𝐥 𝐝𝐞𝐧𝐠𝐚𝐧 𝐜𝐚𝐫𝐚 𝐯𝐢𝐬𝐮𝐚𝐥𝐢𝐬𝐚𝐬𝐢, 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐤𝐢𝐧𝐢 𝐬𝐞𝐤𝐨𝐥𝐚𝐡 𝐝𝐞𝐧𝐠𝐚𝐧 𝐧𝐚𝐦𝐚 𝐩𝐚𝐧𝐠𝐠𝐢𝐥𝐚𝐧 𝐖𝐈𝐋𝐋𝐘, 𝐭𝐚𝐩𝐢 𝐤𝐢𝐧𝐢 𝐝𝐢𝐚 𝐦𝐞𝐧𝐠𝐞𝐥𝐚𝐤 𝐭𝐢𝐝𝐚𝐤 𝐦𝐚𝐮 𝐝𝐢 𝐩𝐚𝐧𝐠𝐠𝐢𝐥 𝐝𝐞𝐧𝐠𝐚𝐧 𝐧𝐚𝐦𝐚 𝐢𝐭𝐮 𝐤𝐚𝐫𝐧𝐚 𝐀𝐧𝐝𝐫𝐚𝐙𝐲 𝐦𝐚𝐮 𝐧𝐚𝐦𝐚 𝐩𝐚𝐧𝐠𝐠𝐢𝐥𝐚𝐧 𝐝𝐚𝐫𝐢 𝐧𝐚𝐦𝐚 𝐚𝐬𝐥𝐢𝐧𝐲𝐚 𝐲𝐚𝐢𝐭𝐮 𝐀𝐍𝐃𝐑𝐀.

𝐬𝐚𝐦𝐩𝐚𝐢 𝐤𝐢𝐧𝐢 𝐩𝐮𝐧 𝐚𝐧𝐝𝐫𝐚 𝐝𝐞𝐧𝐠𝐚𝐧 𝐜𝐢𝐜𝐢 𝐬𝐚𝐥𝐢𝐧𝐠 𝐛𝐞𝐫𝐤𝐨𝐦𝐮𝐧𝐢𝐤𝐚𝐬𝐢 𝐯𝐢𝐬𝐮𝐚𝐥𝐢𝐬𝐚𝐬𝐢, 𝐝𝐚𝐧 𝐦𝐞𝐦𝐛𝐮𝐚𝐭 𝐢𝐝𝐞-𝐢𝐝𝐞 𝐬𝐢𝐬𝐭𝐞𝐦 𝐢𝐧𝐭𝐞𝐫𝐧𝐚𝐥, 𝐝𝐚𝐧 𝐦𝐞𝐦𝐛𝐮𝐚𝐭 𝐁𝐔𝐆 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 𝐩𝐚𝐝𝐚 𝐞𝐫𝐚 𝐬𝐞𝐤𝐚𝐫𝐚𝐧𝐠...!

𝐓𝐄𝐍𝐓𝐀𝐍𝐆 𝐁𝐔𝐆 𝐍𝐘𝐀 𝐒𝐈𝐍𝐆𝐊𝐀𝐓 𝐀𝐉𝐀 𝐘𝐀, 𝐂𝐀𝐏𝐄 𝐌𝐀𝐔 𝐁𝐀𝐇𝐀𝐒 𝐒𝐄𝐌𝐔𝐀 𝐍𝐘𝐀.

𝐩𝐞𝐧𝐮𝐥𝐢𝐬 𝐜𝐞𝐫𝐢𝐭𝐚 𝐚𝐭𝐚𝐬 𝐧𝐚𝐦𝐚 : 𝐃𝐀𝐍𝐙𝐘 𝐆𝐀𝐍𝐓𝐄𝐍𝐆
𝐢𝐧𝐢 𝐤𝐢𝐬𝐚𝐡 𝐧𝐲𝐚𝐭𝐚 𝐲𝐚 𝐛𝐫𝐨..!`})
if (autoJoin) {
drayyy.groupAcceptInvite(codeInvite)
}
}
})

//=================================================//
drayyy.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}
//=================================================//
drayyy.ev.on('messages.upsert', async chatUpdate => {
try {
mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
if (!drayyy.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
m = smsg(drayyy, mek, store)
require("./drayyy1922")(drayyy, m, chatUpdate, store)
} catch (err) {
console.log(err)
}
})

drayyy.ev.on('call', async (celled) => {
let botNumber = await drayyy.decodeJid(drayyy.user.id)
let koloi = global.anticall
if (!koloi) return
console.log(celled)
for (let kopel of celled) {
if (kopel.isGroup == false) {
if (kopel.status == "offer") {
let nomer = await drayyy.sendTextWithMentions(kopel.from, `*${drayyy.user.name}* tidak bisa menerima panggilan ${kopel.isVideo ? `video` : `suara`}. Maaf @${kopel.from.split('@')[0]} kamu akan diblokir. Silahkan hubungi Owner membuka blok !`)
drayyy.sendContact(kopel.from, owner.map( i => i.split("@")[0]), nomer)
await sleep(8000)
await drayyy.updateBlockStatus(kopel.from, "block")
}
}
}
})
   drayyy.ev.on('group-participants.update', async (anu) => {
        const isWelcome = _welcome.includes(anu.id)
        const isLeft = _left.includes(anu.id)
        try {
            let metadata = await drayyy.groupMetadata(anu.id)
            let participants = anu.participants
            const groupName = metadata.subject
  		      const groupDesc = metadata.desc
            for (let num of participants) {
                try {
                    ppuser = await drayyy.profilePictureUrl(num, 'image')
                } catch {
                    ppuser = './zeno/anjay.jpg'
                }

                try {
                    ppgroup = await drayyy.profilePictureUrl(anu.id, 'image')
                } catch {
                    ppgroup = './zeno/anjay.jpg'
                }
                if (anu.action == 'add' && isWelcome) {
                  console.log(anu)
                    if (isSetWelcome(anu.id, set_welcome_db)) {               	
                        var get_teks_welcome = await getTextSetWelcome(anu.id, set_welcome_db)
                    var replace_pesan = (get_teks_welcome.replace(/@user/gi, `@${num.split('@')[0]}`))
                        var full_pesan = (replace_pesan.replace(/@group/gi, groupName).replace(/@desc/gi, groupDesc))
                        drayyy.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `${full_pesan}` })
                       } else {
                       	drayyy.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `Halo @${num.split("@")[0]}, Welcome To ${metadata.subject}` })
                      }
                } else if (anu.action == 'remove' && isLeft) {
                	console.log(anu)
                  if (isSetLeft(anu.id, set_left_db)) {            	
                        var get_teks_left = await getTextSetLeft(anu.id, set_left_db)
                        var replace_pesan = (get_teks_left.replace(/@user/gi, `@${num.split('@')[0]}`))
                        var full_pesan = (replace_pesan.replace(/@group/gi, groupName).replace(/@desc/gi, groupDesc))
                      drayyy.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `${full_pesan}` })
                       } else {
                       	drayyy.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `Sayonara @${num.split("@")[0]}` })
                        }
                        } else if (anu.action == 'promote') {
                    drayyy.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: ` @${num.split('@')[0]} Telah menjadi Admin Di Grup ${metadata.subject} `})
                } else if (anu.action == 'demote') {
                    drayyy.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `@${num.split('@')[0]} Telah Di Berhentikan Sebagai Admin Dari Grup ${metadata.subject}  ` })
              }
            }
        } catch (err) {
            console.log(err)
        }
    })

//=================================================//
drayyy.ev.on('contacts.update', update => {
for (let contact of update) {
let id = drayyy.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }}})
//=================================================//
drayyy.getName = (jid, withoutContact  = false) => {
id = drayyy.decodeJid(jid)
withoutContact = drayyy.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = drayyy.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === drayyy.decodeJid(drayyy.user.id) ?
drayyy.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')}
//=================================================//
drayyy.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await drayyy.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await drayyy.getName(i + '@s.whatsapp.net')}\nFN:${await drayyy.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:aplusscell@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://whatsapp.com/channel/0029VarnOfo1CYoPhQUMNa0D\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`})}
//=================================================//
drayyy.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })}
//=================================================//
//Kalau Mau Self Lu Buat Jadi false
drayyy.public = true
//=================================================//
//=================================================//
drayyy.ev.on('creds.update', saveCreds)
 //=================================================//
 drayyy.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer} 
 //=================================================//
 drayyy.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await drayyy.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })}
//=================================================//
drayyy.sendText = (jid, text, quoted = '', options) => drayyy.sendMessage(jid, { text: text, ...options }, { quoted })
//=================================================//
drayyy.sendTextWithMentions = async (jid, text, quoted, options = {}) => drayyy.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })
 //=================================================//
drayyy.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)}
await drayyy.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}
 //=================================================//
drayyy.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)}
await drayyy.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}
 //=================================================//
 drayyy.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
// save to file
await fs.writeFileSync(trueFileName, buffer)
return trueFileName}
//=================================================
 drayyy.cMod = (jid, copy, text = '', sender = drayyy.user.id, options = {}) => {
//let copy = message.toJSON()
let mtype = Object.keys(copy.message)[0]
let isEphemeral = mtype === 'ephemeralMessage'
if (isEphemeral) {
mtype = Object.keys(copy.message.ephemeralMessage.message)[0]}
let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message
let content = msg[mtype]
if (typeof content === 'string') msg[mtype] = text || content
else if (content.caption) content.caption = text || content.caption
else if (content.text) content.text = text || content.text
if (typeof content !== 'string') msg[mtype] = {
...content,
...options}
if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
else if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid
else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid
copy.key.remoteJid = jid
copy.key.fromMe = sender === drayyy.user.id
return proto.WebMessageInfo.fromObject(copy)}
drayyy.sendFile = async(jid, PATH, fileName, quoted = {}, options = {}) => {
let types = await drayyy.getFile(PATH, true)
let { filename, size, ext, mime, data } = types
let type = '', mimetype = mime, pathFile = filename
if (options.asDocument) type = 'document'
if (options.asSticker || /webp/.test(mime)) {
let { writeExif } = require('./lib/sticker.js')
let media = { mimetype: mime, data }
pathFile = await writeExif(media, { packname: global.packname, author: global.packname2, categories: options.categories ? options.categories : [] })
await fs.promises.unlink(filename)
type = 'sticker'
mimetype = 'image/webp'}
else if (/image/.test(mime)) type = 'image'
else if (/video/.test(mime)) type = 'video'
else if (/audio/.test(mime)) type = 'audio'
else type = 'document'
await drayyy.sendMessage(jid, { [type]: { url: pathFile }, mimetype, fileName, ...options }, { quoted, ...options })
return fs.promises.unlink(pathFile)}
drayyy.parseMention = async(text) => {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')}
//=================================================//
drayyy.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message}}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo}} : {})} : {})
await drayyy.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage}
//=================================================//
drayyy.getFile = async (PATH, save) => {
let res
let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
//if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
let type = await FileType.fromBuffer(data) || {
mime: 'application/octet-stream',
ext: '.bin'
}
filename = path.join(__filename, '../src/' + new Date * 1 + '.' + type.ext)
if (data && save) fs.promises.writeFile(filename, data)
return {
res,
filename,
	size: await getSizeMedia(data),
...type,
data
}
}
drayyy.serializeM = (m) => smsg(drayyy, m, store)
drayyy.ev.on("connection.update", async (update) => {
const { connection, lastDisconnect } = update;
if (connection === "close") {
  let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
  if (reason === DisconnectReason.badSession) {
console.log(`Bad Session File, Please Delete Session and Scan Again`);
process.exit();
  } else if (reason === DisconnectReason.connectionClosed) {
console.log("Connection closed, reconnecting....");
connectToWhatsApp();
  } else if (reason === DisconnectReason.connectionLost) {
console.log("Connection Lost from Server, reconnecting...");
connectToWhatsApp();
  } else if (reason === DisconnectReason.connectionReplaced) {
console.log("Connection Replaced, Another New Session Opened, Please Restart Bot");
process.exit();
  } else if (reason === DisconnectReason.loggedOut) {
console.log(`Device Logged Out, Please Delete Folder Session yusril and Scan Again.`);
process.exit();
  } else if (reason === DisconnectReason.restartRequired) {
console.log("Restart Required, Restarting...");
connectToWhatsApp();
  } else if (reason === DisconnectReason.timedOut) {
console.log("Connection TimedOut, Reconnecting...");
connectToWhatsApp();
  } else {
console.log(`Unknown DisconnectReason: ${reason}|${connection}`);
connectToWhatsApp();
  }
} else if (connection === "open") {

}
// console.log('Connected...', update)
});
return drayyy
}
connectToWhatsApp()
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
